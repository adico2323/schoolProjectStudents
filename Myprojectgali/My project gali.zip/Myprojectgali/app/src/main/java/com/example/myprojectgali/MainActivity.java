package com.example.myprojectgali;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.time.Instant;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
EditText et_UserName,et_Pass;
Button bt_login,bt_signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et_UserName=findViewById(R.id.et_UserName);
        et_Pass=findViewById(R.id.et_Pass);
        bt_login=findViewById(R.id.bt_login);
        bt_signup=findViewById(R.id.bt_signupS);
        bt_signup.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v==bt_signup)
        {
            startActivity(new Intent(this,StudentOrTeacher.class));
        }
    }
}
