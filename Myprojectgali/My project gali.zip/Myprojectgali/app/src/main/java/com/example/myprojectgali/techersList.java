package com.example.myprojectgali;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class techersList extends AppCompatActivity {
    ListView techer_lst;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_techers_list);
        techer_lst=findViewById(R.id.techer_lst);
    }
}
