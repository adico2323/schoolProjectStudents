package com.example.myprojectgali;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class StudentOrTeacher extends AppCompatActivity implements View.OnClickListener {
Button bt_IamS, bt_IamT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_or_teacher);
        bt_IamS=findViewById(R.id.bt_IamS);
        bt_IamT=findViewById(R.id.bt_IamT);
        bt_IamS.setOnClickListener(this);
        bt_IamT.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v==bt_IamS)
        {
            startActivity(new Intent(this,signUpStudent.class));
        }
        if(v==bt_IamT)
        {
            startActivity(new Intent(this,signUpTeacher.class));
        }
    }
}
