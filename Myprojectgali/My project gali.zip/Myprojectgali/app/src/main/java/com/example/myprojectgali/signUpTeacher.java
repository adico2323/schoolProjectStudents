package com.example.myprojectgali;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class signUpTeacher extends AppCompatActivity {
    EditText et_su_UserNameT,et_su_Pass1T,et_su_Pass2T;
    Button bt_signupT;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_teacher);
        et_su_UserNameT=findViewById(R.id.et_su_UserNameT);
        et_su_Pass1T=findViewById(R.id.et_su_Pass1T);
        et_su_Pass2T=findViewById(R.id.et_su_Pass2T);
        bt_signupT=findViewById(R.id.bt_signupT);
    }
}
