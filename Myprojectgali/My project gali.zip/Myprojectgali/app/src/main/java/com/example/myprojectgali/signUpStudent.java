package com.example.myprojectgali;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class signUpStudent extends AppCompatActivity {
    EditText et_su_UserNameS, et_su_Pass1S,et_su_Pass2S;
    Button bt_signupS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_student);
        et_su_UserNameS=findViewById(R.id.et_su_UserNameS);
        et_su_Pass1S=findViewById(R.id.et_su_Pass1S);
        et_su_Pass2S=findViewById(R.id.et_su_Pass2S);
        bt_signupS=findViewById(R.id.bt_signupS);
    }
}
